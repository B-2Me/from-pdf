import os, random, sys, time, re, collections
from google import genai
from openai import OpenAI

model_usage_stats = collections.defaultdict(int)
disabled_providers = set()

def call_llm(prompt, pass_name):
    global model_usage_stats, disabled_providers
    models = [
        {'provider': 'google', 'model': 'gemini-3.5-flash-lite'},
        {'provider': 'google', 'model': 'gemini-3.1-flash-lite'},
        {'provider': 'openrouter', 'model': 'nvidia/nemotron-3-ultra-550b-a55b:free'}
    ]
    for cfg in models:
        provider, model_name = cfg['provider'], cfg['model']
        if provider in disabled_providers: continue
        attempt, max_retries, delay = 1, 3, 5
        while attempt <= max_retries:
            try:
                if provider == 'google':
                    client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                    res = client.models.generate_content(model=model_name, contents=prompt).text
                elif provider == 'openrouter':
                    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                    res = client.chat.completions.create(model=model_name, messages=[{"role": "user", "content": prompt}]).choices[0].message.content
                if res:
                    model_usage_stats[model_name] += 1
                    return res
            except Exception as e:
                error_str = str(e)
                if any(err in error_str for err in ['403', 'PERMISSION_DENIED', '401']):
                    disabled_providers.add(provider)
                    break 
                if '404' in error_str: break 
                if any(err in error_str for err in ['429', 'RESOURCE_EXHAUSTED', 'RateLimit']): time.sleep(15.0)
                else:
                    time.sleep(delay + random.uniform(0.5, 2.0))
                    delay = min(delay * 2, 60)
            attempt += 1
    print("\n❌ FATAL: All models exhausted.", flush=True)
    sys.exit(1)

def process_document(clean_path, output_path, summary_path):
    with open(clean_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    # Batch by max token length (6000 chars) to ensure a 1-page PDF is 1 API call
    paragraphs = raw_text.split('\n\n')
    batches, current_batch = [], ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    final_document = []

    for i, batch in enumerate(batches):
        print(f"-> Processing Batch {i+1}/{len(batches)}...", flush=True)
        prompt = f"""You are an expert document reconstruction AI. Your task is to reformat the provided OCR text into beautiful, structured Markdown.

        CRITICAL RULES:
        1. ZERO DATA LOSS: You must include every single word from the source text. Trailing footnotes, URLs, and contact info at the very bottom are frequently lost—you MUST preserve them.
        2. STRICT MARKDOWN ONLY: You are absolutely forbidden from using HTML tags like `<ul>`, `<li>`, `<p>`, or `<b>`. Use standard Markdown (`-` for lists, `**` for bold). The ONLY permitted HTML is `<br>` strictly inside table cells.
        3. MATH: Convert pseudo-LaTeX or broken math into standard LaTeX equations ($...$ or $$...$$).

        REQUIRED OUTPUT FORMAT:
        You must process the text sequentially and output ONLY the following XML blocks:

        <scratchpad>
        1. Quote the EXACT last 15 words of the source text to anchor your memory.
        2. Outline the sections you see (e.g., "Intro paragraph, bulleted list, schedule table, trailing footer").
        3. Explicitly state: "I will not use HTML tags. I will preserve the final sentence."
        </scratchpad>

        <text_block>
        (Standard paragraphs, lists, headers, and trailing footers formatted purely in Markdown)
        </text_block>

        <table_block is_continuation="false">
        (Reconstructed schedules or mapped data as a strict Markdown table `|---|`. Set `is_continuation="true"` ONLY if continuing a table from the previous batch)
        </table_block>

        (Use as many <text_block> and <table_block> tags as needed, alternating as the document dictates. Do not nest them. The final tag MUST contain the trailing text you quoted in the scratchpad.)

        <source_text>
        {batch}
        </source_text>"""
        
        res = call_llm(prompt, "Full Document Anchor Parser")
        
        # Regex ignores the <scratchpad> and only extracts the final markdown blocks
        blocks = re.finditer(r'<(text_block|table_block)([^>]*)>(.*?)</\1>', res, re.DOTALL | re.IGNORECASE)
        for match in blocks:
            tag_name = match.group(1).lower()
            attributes = match.group(2).lower()
            content = match.group(3).strip()
            
            if tag_name == 'text_block':
                final_document.append(content)
            elif tag_name == 'table_block':
                is_continuation = 'is_continuation="true"' in attributes
                
                if is_continuation and final_document and '|' in final_document[-1]:
                    lines = content.split('\n')
                    merged_rows = []
                    passed_separator = False
                    for line in lines:
                        if re.search(r'\|[\s\-\:]+\|', line):
                            passed_separator = True
                            continue
                        if passed_separator and line.strip():
                            merged_rows.append(line)
                    
                    final_document[-1] += "\n" + "\n".join(merged_rows)
                else:
                    final_document.append(content)

        time.sleep(4)

    print(f"\n-> Saving aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(final_document))
        
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    issue_num = sys.argv[1]
    process_document(
        f"conversions/issue-{issue_num}/fixed/document/document.md",
        f"conversions/issue-{issue_num}/document_aligned.md",
        f"conversions/issue-{issue_num}/model_summary.md"
    )
