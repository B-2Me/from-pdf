import os, random, sys, time, re, collections
from google import genai
from openai import OpenAI

model_usage_stats = collections.defaultdict(int)
disabled_providers = set()

def call_llm(prompt, pass_name):
    global model_usage_stats, disabled_providers
    models = [
        {'provider': 'google', 'model': 'gemini-3.5-flash-lite'},
        {'provider': 'google', 'model': 'gemini-3.1-flash-lite'},
        {'provider': 'openrouter', 'model': 'nvidia/nemotron-3-ultra-550b-a55b:free'}
    ]
    for cfg in models:
        provider, model_name = cfg['provider'], cfg['model']
        if provider in disabled_providers: continue
        attempt, max_retries, delay = 1, 3, 5
        while attempt <= max_retries:
            try:
                if provider == 'google':
                    client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                    res = client.models.generate_content(model=model_name, contents=prompt).text
                elif provider == 'openrouter':
                    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                    res = client.chat.completions.create(model=model_name, messages=[{"role": "user", "content": prompt}]).choices[0].message.content
                if res:
                    model_usage_stats[model_name] += 1
                    return res
            except Exception as e:
                error_str = str(e)
                if any(err in error_str for err in ['403', 'PERMISSION_DENIED', '401']):
                    disabled_providers.add(provider)
                    break 
                if '404' in error_str: break 
                if any(err in error_str for err in ['429', 'RESOURCE_EXHAUSTED', 'RateLimit']): time.sleep(15.0)
                else:
                    time.sleep(delay + random.uniform(0.5, 2.0))
                    delay = min(delay * 2, 60)
            attempt += 1
    print("\n❌ FATAL: All models exhausted.", flush=True)
    sys.exit(1)

def process_document(clean_path, output_path, summary_path):
    with open(clean_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    paragraphs = raw_text.split('\n\n')
    batches, current_batch = [], ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    final_document = []

    for i, batch in enumerate(batches):
        print(f"-> Processing Batch {i+1}/{len(batches)}...", flush=True)
        prompt = f"""You are a strict document parser. Completely reformat the provided document sequentially from top to bottom.
        
        CRITICAL FAILURE MODE AWARENESS:
        When formatting tables, AIs frequently and accidentally delete the non-tabular text immediately following the table (such as footnotes, URLs, contact info, or trailing paragraphs). You MUST explicitly scan the text at the bottom of tables to ensure no text is accidentally omitted from your output.
        
        CRITICAL RULES:
        1. ZERO DATA LOSS: Every single word from the source must survive.
        2. STRICT MARKDOWN: Inside `<table_block>`, you may ONLY use `|---|` syntax, `- ` for lists, and `<br>` for newlines.
        3. ABSOLUTELY NO HTML: Do NOT use `<ul>`, `<li>`, `<p>`, or `<b>` tags anywhere. Apply Markdown bolding (`**`) instead.
        4. Convert broken math into LaTeX ($...$ or $$...$$).
        
        OUTPUT FORMAT:
        Wrap the document sequentially using ONLY these two XML tags:
        <text_block>
        (For all standard paragraphs, headers, and text immediately preceding or following tables)
        </text_block>
        
        <table_block>
        (For strictly formatted Markdown tables)
        </table_block>
        
        <source_document>
        {batch}
        </source_document>"""
        
        res = call_llm(prompt, "Full Document Sequential Parser")
        
        blocks = re.finditer(r'<(text_block|table_block)>(.*?)</\1>', res, re.DOTALL | re.IGNORECASE)
        for match in blocks:
            content = match.group(2).strip()
            if content: final_document.append(content)

        time.sleep(4)

    print(f"\n-> Saving aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(final_document))
        
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    issue_num = sys.argv[1]
    process_document(
        f"conversions/issue-{issue_num}/fixed/document/document.md",
        f"conversions/issue-{issue_num}/document_aligned.md",
        f"conversions/issue-{issue_num}/model_summary.md"
    )
