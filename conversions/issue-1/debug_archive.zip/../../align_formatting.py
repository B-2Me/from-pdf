import os, random, sys, time, re, collections
from google import genai
from openai import OpenAI

# ==============================================================================
# MODEL CONFIGURATION
# To collapse back to a single model, simply remove all but one dictionary here!
# ==============================================================================
MODELS_TO_EVALUATE = [
    {
        "id": "nemotron_ultra",
        "provider": "openrouter",
        "model": "nvidia/nemotron-3-ultra-550b-a55b:free"
    },
    {
        "id": "nemotron_lightning",
        "provider": "openrouter",
        "model": "nvidia/nemotron-3.5-lightning:free"
    },
    {
        "id": "gemini_flash",
        "provider": "google",
        "model": "gemini-2.5-flash-lite"
    }
]

model_usage_stats = collections.defaultdict(int)

def call_single_model(cfg, prompt):
    provider = cfg['provider']
    model_name = cfg['model']
    
    attempt, max_retries, delay = 1, 3, 5
    while attempt <= max_retries:
        try:
            if provider == 'google':
                client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                res = client.models.generate_content(model=model_name, contents=prompt).text
            elif provider == 'openrouter':
                client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                res = client.chat.completions.create(
                    model=model_name,
                    messages=[{"role": "user", "content": prompt}]
                ).choices[0].message.content
            
            if res:
                model_usage_stats[f"{cfg['id']} ({model_name})"] += 1
                return res
        except Exception as e:
            err_str = str(e)
            print(f"[{cfg['id']} Attempt {attempt} Failed]: {err_str[:120]}", flush=True)
            if any(k in err_str for k in ['403', '401', 'PERMISSION_DENIED']):
                break
            if any(k in err_str for k in ['429', 'RateLimit', 'RESOURCE_EXHAUSTED']):
                time.sleep(15.0)
            else:
                time.sleep(delay + random.uniform(0.5, 2.0))
                delay = min(delay * 2, 60)
        attempt += 1
    return None

def format_with_model(cfg, raw_text):
    print(f"\n==================================================", flush=True)
    print(f"-> Generating comparison with: {cfg['id']} ({cfg['model']})", flush=True)
    print(f"==================================================", flush=True)

    paragraphs = raw_text.split('\n\n')
    batches, current_batch = [], ""
    for p in paragraphs:
        if not p.strip(): continue
        if len(current_batch) + len(p) > 6000:
            batches.append(current_batch)
            current_batch = p
        else:
            current_batch += "\n\n" + p if current_batch else p
    if current_batch:
        batches.append(current_batch)

    model_output_blocks = []

    for i, batch in enumerate(batches):
        prompt = f"""You are a precise document reconstruction AI. Your task is to format raw OCR text into pristine Markdown.

        CRITICAL RULES:
        1. ZERO DATA LOSS: Every single word from the source text must exist in your output.
        2. PREVENT ATTENTION DECAY: When finishing a table, NEVER drop the trailing non-table text (URLs, footers, notes). The last row of a table is NOT the document footer!
        3. STRICT MARKDOWN: Absolutely NO HTML tags (no <ul>, <li>, <p>, <b>). Use standard Markdown (`-` for lists, `**` for bold). Only `<br>` is permitted inside table cells.
        4. Convert broken math into LaTeX ($...$ or $$...$$).

        REQUIRED OUTPUT FORMAT:
        <scratchpad>
        - Exact last 20 words of this text: "..."
        - Is there text after the table? State it explicitly here so you do not omit it.
        </scratchpad>

        <text_block>
        (Headings, intro paragraphs, bulleted lists preceding tables)
        </text_block>

        <table_block is_continuation="false">
        (Strict Markdown table syntax: |---|)
        </table_block>

        <text_block>
        (Trailing text, URLs, and footnotes following the table)
        </text_block>

        <source_text>
        {batch}
        </source_text>"""

        res = call_single_model(cfg, prompt)
        if not res:
            print(f"❌ Skipping {cfg['id']} due to API failure.", flush=True)
            return None

        blocks = re.finditer(r'<(text_block|table_block)([^>]*)>(.*?)</\1>', res, re.DOTALL | re.IGNORECASE)
        for match in blocks:
            tag_name = match.group(1).lower()
            attributes = match.group(2).lower()
            content = match.group(3).strip()

            if tag_name == 'text_block':
                model_output_blocks.append(content)
            elif tag_name == 'table_block':
                is_continuation = 'is_continuation="true"' in attributes
                if is_continuation and model_output_blocks and '|' in model_output_blocks[-1]:
                    lines = content.split('\n')
                    merged_rows = []
                    passed_sep = False
                    for line in lines:
                        if re.search(r'\|[\s\-\:]+\|', line):
                            passed_sep = True
                            continue
                        if passed_sep and line.strip():
                            merged_rows.append(line)
                    model_output_blocks[-1] += "\n" + "\n".join(merged_rows)
                else:
                    model_output_blocks.append(content)

        time.sleep(3)

    return '\n\n'.join(model_output_blocks)

def main(issue_num):
    base_dir = f"conversions/issue-{issue_num}"
    raw_path = f"{base_dir}/fixed/document/document.md"
    
    with open(raw_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    is_single_mode = len(MODELS_TO_EVALUATE) == 1

    for idx, cfg in enumerate(MODELS_TO_EVALUATE):
        result_md = format_with_model(cfg, raw_text)
        if not result_md: continue

        if is_single_mode:
            out_file = f"{base_dir}/document_aligned.md"
        else:
            out_file = f"{base_dir}/document_aligned_{cfg['id']}.md"
            # Keep a primary document_aligned.md pointing to the first evaluated model
            if idx == 0:
                with open(f"{base_dir}/document_aligned.md", 'w', encoding='utf-8') as f:
                    f.write(result_md)

        with open(out_file, 'w', encoding='utf-8') as f:
            f.write(result_md)
        print(f"Saved: {out_file}", flush=True)

    summary_path = f"{base_dir}/model_summary.md"
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    main(sys.argv[1])
