import os, random, sys, time, re, collections, json
from google import genai
from openai import OpenAI

model_usage_stats = collections.defaultdict(int)
disabled_providers = set()

def call_llm(prompt, pass_name):
    global model_usage_stats, disabled_providers
    models = [
        {'provider': 'google', 'model': 'gemini-3.5-flash-lite'},
        {'provider': 'google', 'model': 'gemini-3.1-flash-lite'},
        {'provider': 'openrouter', 'model': 'nvidia/nemotron-3-ultra-550b-a55b:free'}
    ]
    for cfg in models:
        provider, model_name = cfg['provider'], cfg['model']
        if provider in disabled_providers: continue
        attempt, max_retries, delay = 1, 3, 5
        while attempt <= max_retries:
            try:
                if provider == 'google':
                    client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                    res = client.models.generate_content(model=model_name, contents=prompt).text
                elif provider == 'openrouter':
                    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                    res = client.chat.completions.create(model=model_name, messages=[{"role": "user", "content": prompt}]).choices[0].message.content
                if res:
                    model_usage_stats[model_name] += 1
                    return res
            except Exception as e:
                error_str = str(e)
                if any(err in error_str for err in ['403', 'PERMISSION_DENIED', '401']):
                    disabled_providers.add(provider)
                    break 
                if '404' in error_str: break 
                if any(err in error_str for err in ['429', 'RESOURCE_EXHAUSTED', 'RateLimit']): time.sleep(15.0)
                else:
                    time.sleep(delay + random.uniform(0.5, 2.0))
                    delay = min(delay * 2, 60)
            attempt += 1
    print("\n❌ FATAL: All models exhausted.", flush=True)
    sys.exit(1)

def process_document(clean_path, output_path, summary_path):
    with open(clean_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    print("-> [Pass 1] Semantic Segmentation...", flush=True)
    segmentation_prompt = f"""You are a precise document segmentation AI. Divide the provided text into logical, standalone structural chunks.
    
    CRITICAL RULES:
    1. Output MUST be a JSON array of strings.
    2. Do NOT add, modify, or delete a single character. Every character from the source text must be accounted for within the strings.
    3. Split the text strictly at structural boundaries (e.g., between a standard paragraph and a schedule, or between a list and a footer).
    
    Example Output:
    ```json
    [
      "**Requirements:**\\n- Dream journal and pen\\n- 2 alarm clocks",
      "A. Prepare (30 minutes)\\n10:30pm\\nSetup 2 alarms...",
      "Optional: Send me your feedback, questions, or dream experience: [www.YouCanLucidDream.com/contact](https://www.YouCanLucidDream.com/contact)"
    ]
    ```
    
    <source_document>
    {raw_text}
    </source_document>"""
    
    seg_res = call_llm(segmentation_prompt, "Document Splitter")
    json_match = re.search(r'```(?:json)?\n(.*?)```', seg_res, re.DOTALL | re.IGNORECASE)
    json_str = json_match.group(1).strip() if json_match else seg_res.strip()
    
    try:
        chunks = json.loads(json_str)
    except Exception as e:
        print(f"   [⚠️ JSON Parse Failed: {e}] Falling back to naive Python split.", flush=True)
        chunks = [c.strip() for c in raw_text.split('\n\n') if c.strip()]
        
    final_document = []
    
    print("\n-> [Pass 2] Targeted Formatting...", flush=True)
    for i, chunk in enumerate(chunks):
        print(f"   Processing Chunk {i+1}/{len(chunks)}...", flush=True)
        
        list_markers = sum(1 for line in chunk.split('\n') if re.match(r'^[\-\*\•\d]', line.strip()))
        has_times = bool(re.search(r'\d{1,2}:\d{2}\s*(am|pm)', chunk, re.IGNORECASE))
        
        if (list_markers >= 2 and len(chunk.split('\n')) >= 3) or (has_times and len(chunk.split('\n')) >= 3):
            prompt = f"""Convert this exact text block into a Markdown table (`|---|`). 
            CRITICAL RULES: 
            1. DO NOT add, summarize, or delete any words. Keep the exact text, just map it into columns. 
            2. Use `<br>` for line breaks in cells.
            3. Convert pseudo-LaTeX or broken math into standard LaTeX equations ($...$ or $$...$$).
            4. Output ONLY the table.
            
            <text>
            {chunk}
            </text>"""
            
            res = call_llm(prompt, "Table Builder")
            md = re.search(r'```(?:markdown)?\n(.*?)\n```', res, re.DOTALL)
            final_document.append(md.group(1).strip() if md else res.strip())
        else:
            prompt = f"""Apply bold and italic markdown to this text to make it readable. 
            CRITICAL RULES: 
            1. DO NOT format this as a table. 
            2. DO NOT add, summarize, or delete any words. Output ONLY the exact text provided, with inline markdown applied.
            3. Convert pseudo-LaTeX or broken math into standard LaTeX equations ($...$ or $$...$$).
            
            <text>
            {chunk}
            </text>"""
            
            res = call_llm(prompt, "Inline Formatter")
            final_document.append(res.replace('```markdown', '').replace('```', '').strip())
            
        time.sleep(2) # Prevent rapid-fire rate limiting

    print(f"\n-> Saving aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(final_document))
        
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    issue_num = sys.argv[1]
    process_document(
        f"conversions/issue-{issue_num}/fixed/document/document.md",
        f"conversions/issue-{issue_num}/document_aligned.md",
        f"conversions/issue-{issue_num}/model_summary.md"
    )
