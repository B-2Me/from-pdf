import os, random, sys, time, re, collections, json
from pathlib import Path
from google import genai
from openai import OpenAI

model_usage_stats = collections.defaultdict(int)
disabled_providers = set()

def call_llm(prompt, pass_name):
    global model_usage_stats, disabled_providers
    models = [
        {'provider': 'google', 'model': 'gemini-3.5-flash-lite'},
        {'provider': 'google', 'model': 'gemini-3.1-flash-lite'},
        {'provider': 'openrouter', 'model': 'nvidia/nemotron-3-ultra-550b-a55b:free'}
    ]
    
    for cfg in models:
        provider, model_name = cfg['provider'], cfg['model']
        if provider in disabled_providers: continue
        
        attempt, max_retries, delay = 1, 3, 5
        while attempt <= max_retries:
            try:
                if provider == 'google':
                    client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                    res = client.models.generate_content(model=model_name, contents=prompt).text
                elif provider == 'openrouter':
                    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                    res = client.chat.completions.create(model=model_name, messages=[{"role": "user", "content": prompt}]).choices[0].message.content
                
                if res:
                    model_usage_stats[model_name] += 1
                    return res
            except Exception as e:
                error_str = str(e)
                if any(err in error_str for err in ['403', 'PERMISSION_DENIED', '401']):
                    disabled_providers.add(provider)
                    break 
                if '404' in error_str: break 
                if any(err in error_str for err in ['429', 'RESOURCE_EXHAUSTED', 'RateLimit']):
                    time.sleep(15.0)
                else:
                    time.sleep(delay + random.uniform(0.5, 2.0))
                    delay = min(delay * 2, 60)
            attempt += 1
    print("\n❌ FATAL: All models exhausted.", flush=True)
    sys.exit(1)

def process_document(clean_path, output_path, summary_path):
    with open(clean_path, 'r', encoding='utf-8') as f:
        clean_text = f.read()

    blocks = [b.strip() for b in clean_text.split('\n\n') if b.strip()]
    final_document = []

    for i, block in enumerate(blocks):
        print(f"-> Processing Block {i+1}/{len(blocks)}...", flush=True)
        lines = block.split('\n')
        
        list_markers = sum(1 for line in lines if re.match(r'^[\-\*\•\d]', line.strip()))
        has_times = bool(re.search(r'\d{1,2}:\d{2}\s*(am|pm)', block, re.IGNORECASE))
        
        if (list_markers >= 2 and len(lines) >= 3) or (has_times and len(lines) >= 3):
            print("   [LLM Route] Structural block detected. Converting to table via JSON...", flush=True)
            prompt = f"""You are a precise data formatter. Convert the provided text into a Markdown table and extract surrounding text.
            
            CRITICAL RULES:
            1. NEVER use HTML tags like `<ul>`, `<li>`, `<p>`, or `<b>`. Use standard Markdown bullet points (`- `) and `<br>` for line breaks inside cells. Use `**` for bolding.
            2. Extract any titles or intro sentences into `preceding_text`.
            3. Extract any footers, URLs, or notes at the bottom into `trailing_text`. DO NOT delete this text!
            4. Output ONLY valid JSON inside a code block.
            
            ```json
            {{
              "preceding_text": "...",
              "table_markdown": "| Header |...\\n|---|...\\n",
              "trailing_text": "..."
            }}
            ```
            
            <text>
            {block}
            </text>"""
            
            res = call_llm(prompt, "Table Builder (JSON)")
            
            json_match = re.search(r'```(?:json)?\n(.*?)```', res, re.DOTALL | re.IGNORECASE)
            json_str = json_match.group(1).strip() if json_match else res.strip()
            
            try:
                data = json.loads(json_str)
                if data.get("preceding_text"): final_document.append(data["preceding_text"].strip())
                if data.get("table_markdown"): final_document.append(data["table_markdown"].strip())
                if data.get("trailing_text"): 
                    final_document.append(data["trailing_text"].strip())
                    print(f"      [🔍 SAVED ORPHAN TEXT]: '{data['trailing_text'][:50]}...'")
            except Exception as e:
                print(f"   [⚠️ JSON Parse Failed: {e}] Falling back to raw string regex.")
                md = re.search(r'```(?:markdown)?\n(.*?)\n```', res, re.DOTALL)
                final_document.append(md.group(1).strip() if md else res.strip())
        else:
            print("   [Python Route] Standard text detected. Formatting inline...", flush=True)
            prompt = f"""Apply bold and italic markdown to this text to make it readable. 
            CRITICAL RULES: 
            1. DO NOT format this as a table. 
            2. DO NOT add, summarize, or delete any words. Output ONLY the exact text provided, with inline markdown applied.
            3. NO HTML ALLOWED. Do not use `<p>`, `<ul>`, or `<li>`. Use standard markdown.
            
            <text>
            {block}
            </text>"""
            
            res = call_llm(prompt, "Inline Formatter")
            final_document.append(res.replace('```markdown', '').replace('```', '').strip())
            
        time.sleep(4)
        
    print(f"\n-> Saving aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write('\n\n'.join(final_document))
        
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    issue_num = sys.argv[1]
    process_document(
        f"conversions/issue-{issue_num}/fixed/document/document.md",
        f"conversions/issue-{issue_num}/document_aligned.md",
        f"conversions/issue-{issue_num}/model_summary.md"
    )
