import os, random, sys, time, re, collections, json
from google import genai
from openai import OpenAI

model_usage_stats = collections.defaultdict(int)
disabled_providers = set()

def call_llm(prompt, pass_name):
    global model_usage_stats, disabled_providers
    models = [
        {'provider': 'google', 'model': 'gemini-3.5-flash-lite'},
        {'provider': 'google', 'model': 'gemini-3.1-flash-lite'},
        {'provider': 'openrouter', 'model': 'nvidia/nemotron-3-ultra-550b-a55b:free'}
    ]
    for cfg in models:
        provider, model_name = cfg['provider'], cfg['model']
        if provider in disabled_providers: continue
        attempt, max_retries, delay = 1, 3, 5
        while attempt <= max_retries:
            try:
                if provider == 'google':
                    client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY"))
                    res = client.models.generate_content(model=model_name, contents=prompt).text
                elif provider == 'openrouter':
                    client = OpenAI(base_url="https://openrouter.ai/api/v1", api_key=os.environ.get("OPENROUTER_API_KEY"))
                    res = client.chat.completions.create(model=model_name, messages=[{"role": "user", "content": prompt}]).choices[0].message.content
                if res:
                    model_usage_stats[model_name] += 1
                    return res
            except Exception as e:
                error_str = str(e)
                if any(err in error_str for err in ['403', 'PERMISSION_DENIED', '401']):
                    disabled_providers.add(provider)
                    break 
                if '404' in error_str: break 
                if any(err in error_str for err in ['429', 'RESOURCE_EXHAUSTED', 'RateLimit']): time.sleep(15.0)
                else:
                    time.sleep(delay + random.uniform(0.5, 2.0))
                    delay = min(delay * 2, 60)
            attempt += 1
    print("\n❌ FATAL: All models exhausted.", flush=True)
    sys.exit(1)

def find_span(text, start_q, end_q):
    start_words = [re.escape(w) for w in start_q.split()[:10] if w.strip()]
    end_words = [re.escape(w) for w in end_q.split()[-10:] if w.strip()]
    if not start_words or not end_words: return -1, -1
    
    start_pattern = r'\s+'.join(start_words)
    end_pattern = r'\s+'.join(end_words)
    
    s_match = re.search(start_pattern, text, re.IGNORECASE)
    if not s_match: return -1, -1
    start_idx = s_match.start()
    
    e_match = re.search(end_pattern, text[start_idx:], re.IGNORECASE)
    if not e_match: return -1, -1
    end_idx = start_idx + e_match.end()
    
    return start_idx, end_idx

def process_document(clean_path, output_path, summary_path):
    with open(clean_path, 'r', encoding='utf-8') as f:
        raw_text = f.read()

    print("-> [Pass 1] Surgical Table Extraction...", flush=True)
    prompt = f"""You are a precise data-extraction AI. Look at the document below. 
    Find ANY complex schedules, data mappings, or multi-column lists that should be formatted as a Markdown table.
    
    For each table you identify, output a JSON object containing:
    1. "start_quote": The EXACT first 6-8 words from the raw text where the table data begins.
    2. "end_quote": The EXACT last 6-8 words from the raw text where the table data ends.
    3. "table_markdown": The fully reconstructed Markdown table (`|---|`). Use `- ` for lists inside cells and `<br>` for line breaks.
    
    CRITICAL RULES:
    - DO NOT include standard paragraphs, footers, or contact info in your extraction! Python will use your quotes to swap the table in, leaving the rest of the text untouched.
    - Output ONLY a JSON array of objects.
    
    ```json
    [
      {{
        "start_quote": "A. Prepare (30 minutes) Setup",
        "end_quote": "with someone this morning. 7:00 am",
        "table_markdown": "| Phase | Actions |..."
      }}
    ]
    ```
    
    <document>
    {raw_text}
    </document>"""
    
    res = call_llm(prompt, "Table Extraction")
    json_match = re.search(r'```(?:json)?\n(.*?)```', res, re.DOTALL | re.IGNORECASE)
    json_str = json_match.group(1).strip() if json_match else res.strip()
    
    final_text = raw_text
    try:
        tables = json.loads(json_str)
        for idx, tbl in enumerate(tables):
            sq = tbl.get("start_quote", "").strip()
            eq = tbl.get("end_quote", "").strip()
            md = tbl.get("table_markdown", "").strip()
            
            if sq and eq and md:
                start_idx, end_idx = find_span(final_text, sq, eq)
                if start_idx != -1 and end_idx != -1:
                    final_text = final_text[:start_idx] + "\n\n" + md + "\n\n" + final_text[end_idx:]
                    print(f"   [✅ INJECTED TABLE {idx+1}] Swapped raw text with table.", flush=True)
                else:
                    print(f"   [⚠️ ANCHORS NOT FOUND]: sq='{sq}', eq='{eq}'", flush=True)
    except Exception as e:
        print(f"   [⚠️ JSON Parse Failed: {e}]", flush=True)

    print(f"\n-> Saving aligned markdown to: {output_path}", flush=True)
    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(final_text.strip())
        
    with open(summary_path, 'w', encoding='utf-8') as f:
        f.write("### 🤖 Model Usage Summary\n")
        for m, count in model_usage_stats.items():
            f.write(f"- **{m}**: {count} successful calls\n")

if __name__ == "__main__":
    issue_num = sys.argv[1]
    process_document(
        f"conversions/issue-{issue_num}/fixed/document/document.md",
        f"conversions/issue-{issue_num}/document_aligned.md",
        f"conversions/issue-{issue_num}/model_summary.md"
    )
